import os
import subprocess

PATH = "./app/windows"

for root, dirs, files in os.walk(PATH):
    for file in files:
        if file.endswith('.ui'):
            filename_without_ext = os.path.splitext(file)[0]

            ui_path = os.path.join(root, f"{filename_without_ext}.ui")
            py_path = os.path.join(root, f"{filename_without_ext}_ui.py")

            print(f"Компиляция: {ui_path} -> {py_path}")

            subprocess.run(f'pyside6-uic "{ui_path}" -o "{py_path}"', shell=True)