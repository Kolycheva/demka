from PySide6.QtWidgets import QWidget

from app.windows.auth.auth_ui import Ui_AuthPageUI


class AuthPage(QWidget):
    def __init__(self):
        super().__init__()

        self.ui = Ui_AuthPageUI()
        self.ui.setupUi(self)

        self.ui.login_button.clicked.connect(self.login_button_clicked)

    def login_button_clicked(self):
        print("login clicked")