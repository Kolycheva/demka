# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'auth.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QLayout, QLineEdit,
    QPushButton, QSizePolicy, QVBoxLayout, QWidget)

class Ui_AuthPageUI(object):
    def setupUi(self, AuthPageUI):
        if not AuthPageUI.objectName():
            AuthPageUI.setObjectName(u"AuthPageUI")
        AuthPageUI.resize(257, 179)
        self.verticalLayout_2 = QVBoxLayout(AuthPageUI)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setSizeConstraint(QLayout.SizeConstraint.SetMinAndMaxSize)
        self.label = QLabel(AuthPageUI)
        self.label.setObjectName(u"label")

        self.verticalLayout.addWidget(self.label, 0, Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignVCenter)

        self.login_input = QLineEdit(AuthPageUI)
        self.login_input.setObjectName(u"login_input")
        self.login_input.setMaximumSize(QSize(16777215, 22))

        self.verticalLayout.addWidget(self.login_input)

        self.login_button = QPushButton(AuthPageUI)
        self.login_button.setObjectName(u"login_button")

        self.verticalLayout.addWidget(self.login_button)


        self.verticalLayout_2.addLayout(self.verticalLayout)


        self.retranslateUi(AuthPageUI)

        QMetaObject.connectSlotsByName(AuthPageUI)
    # setupUi

    def retranslateUi(self, AuthPageUI):
        AuthPageUI.setWindowTitle(QCoreApplication.translate("AuthPageUI", u"Form", None))
        self.label.setText(QCoreApplication.translate("AuthPageUI", u"\u0412\u0432\u043e\u0439\u0434\u0438\u0442\u0435 \u0432 \u0430\u043a\u043a\u0430\u0443\u043d\u0442", None))
#if QT_CONFIG(whatsthis)
        self.login_input.setWhatsThis("")
#endif // QT_CONFIG(whatsthis)
        self.login_input.setPlaceholderText(QCoreApplication.translate("AuthPageUI", u"\u043b\u043e\u0433\u0438\u043d", None))
        self.login_button.setText(QCoreApplication.translate("AuthPageUI", u"\u0412\u043e\u0439\u0442\u0438", None))
    # retranslateUi

