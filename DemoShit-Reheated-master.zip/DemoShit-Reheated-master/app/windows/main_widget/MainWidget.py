from PySide6.QtWidgets import QStackedWidget, QWidget

from app.windows.auth.auth import AuthPage
from app.windows.main_widget.MainWidget_ui import Ui_MainWidget


class MainWidget(QStackedWidget):
    def __init__(self):
        super().__init__()

        self.ui = Ui_MainWidget()
        self.ui.setupUi(self)

        self.current_page = AuthPage()

    def switch_page(self, next_page: QWidget):
        if not next_page:
            return

        old_page = self.currentWidget()

        new_index = self.addWidget(next_page)

        self.setCurrentIndex(new_index)

        self.current_page = next_page

        if old_page:
            self.removeWidget(old_page)
            old_page.deleteLater()

        self.updateGeometry()
        self.adjustSize()